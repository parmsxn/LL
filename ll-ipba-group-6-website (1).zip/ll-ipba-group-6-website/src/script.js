function openTab(tabName) {
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => {
        tab.style.display = 'none'; // Hide all tabs
    });
    document.getElementById(tabName).style.display = 'block'; // Show the selected tab
}

// Optional: Open the gaming tab by default
document.addEventListener('DOMContentLoaded', () => {
    openTab('gaming');
});
