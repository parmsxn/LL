# LL IPBA Group 6 Website

A Pen created on CodePen.io. Original URL: [https://codepen.io/AP-Student-Sean-Kenneth-Tan/pen/dyxWjwK](https://codepen.io/AP-Student-Sean-Kenneth-Tan/pen/dyxWjwK).

